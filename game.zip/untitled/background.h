#ifndef BACKGROUND_H
#define BACKGROUND_H

#include <string>

bool cargarTexturaBackground(const std::string& nombreArchivo);
void drawBackground();

#endif
