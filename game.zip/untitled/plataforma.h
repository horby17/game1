#ifndef PLATAFORMA_H
#define PLATAFORMA_H

void initPlataforma();
void drawPlataforma();

#endif
