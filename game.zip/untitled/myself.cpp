//
// Created by horby on 04-27-24.
//
#include<GL/glew.h>
#include<GL/glut.h>
#include<iostream>

enum State {WHITE, YELLOW};
State estado = WHITE;

void timer(int value){
    switch (estado) {
        case WHITE:
            estado = YELLOW;
            break;
        case YELLOW:
            estado = WHITE;
            break;
    }
    glutPostRedisplay();
    glutTimerFunc(1000, timer, 0); // Cambia el estado cada 1000 ms (1 segundo)
}
