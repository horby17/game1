//
// Created by horby on 04-27-24.
//
#include <GL/glut.h>
#include <cmath>

// Definimos los estados del semáforo
enum State { RED, YELLOW, GREEN };
State state = RED;

// Función para cambiar el estado del semáforo con un tiempo
void timer(int value) {
    switch (state) {
        case RED:
            state = GREEN;
            break;
        case GREEN:
            state = YELLOW;
            break;
        case YELLOW:
            state = RED;
            break;
    }
    glutPostRedisplay();
    glutTimerFunc(1000, timer, 0); // Cambia el estado cada 1000 ms (1 segundo)
}

// Función para dibujar un círculo
void drawCircle(float x, float y, float radius) {
    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++) {
        float degInRad = i * 3.14159 / 180;
        glVertex2f(x + cos(degInRad) * radius, y + sin(degInRad) * radius);
    }
    glEnd();
}

// Función de renderizado
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Dibuja el fondo del semáforo
    glColor3f(0.1, 0.1, 0.1); // Color gris oscuro para la carcasa
    glBegin(GL_POLYGON);
    glVertex2f(-0.2f, -0.6f);
    glVertex2f(0.2f, -0.6f);
    glVertex2f(0.2f, 0.6f);
    glVertex2f(-0.2f, 0.6f);
    glEnd();

    // Determinar el color de cada círculo basado en el estado
    glColor3f(0.5, 0.0, 0.0); // Rojo oscuro (apagado)
    drawCircle(0.0, 0.3, 0.1);
    glColor3f(0.5, 0.5, 0.0); // Amarillo oscuro (apagado)
    drawCircle(0.0, 0.0, 0.1);
    glColor3f(0.0, 0.5, 0.0); // Verde oscuro (apagado)
    drawCircle(0.0, -0.3, 0.1);

    // Enciende la luz correspondiente
    switch (state) {
        case RED:
            glColor3f(1.0, 0.0, 0.0); // Rojo
            drawCircle(0.0, 0.3, 0.1);
            break;
        case YELLOW:
            glColor3f(1.0, 1.0, 0.0); // Amarillo
            drawCircle(0.0, 0.0, 0.1);
            break;
        case GREEN:
            glColor3f(0.0, 1.0, 0.0); // Verde
            drawCircle(0.0, -0.3, 0.1);
            break;
    }

    glFlush();
}

void initOpenGL() {
    glClearColor(0.0, 0.0, 0.0, 1.0); // Fondo negro
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutCreateWindow("OpenGL Semaforo");
    glutDisplayFunc(display);
    glutTimerFunc(0, timer, 0); // Inicia el timer inmediatamente
    initOpenGL();
    glutMainLoop();
    return 0;
}
